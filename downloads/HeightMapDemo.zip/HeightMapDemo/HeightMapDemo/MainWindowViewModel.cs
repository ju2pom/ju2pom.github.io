﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using Timer = System.Timers.Timer;
using Color = System.Windows.Media.Color;
using PixelFormat = System.Drawing.Imaging.PixelFormat;

namespace HeightMapDemo
{
  public class MainWindowViewModel : INotifyPropertyChanged
  {
    private static readonly IDictionary<double, Color> ColorMap = new Dictionary<double, Color>
      {
        {-1.0000, Color.FromRgb(0, 0, 128)}, // deeps
        {-0.1500, Color.FromRgb(0, 0, 255)}, // shallow
        {0.1000, Color.FromRgb(0, 128, 255)}, // shore
        {0.2900, Color.FromRgb(240, 240, 128)}, // sand
        {0.3000, Color.FromRgb(240, 240, 64)}, // sand
        {0.3500, Color.FromRgb(32, 160, 0)}, // grass
        {0.8000, Color.FromRgb(220, 220, 112)}, // dirt
        {0.8500, Color.FromRgb(128, 128, 128)}, // rock
        {1.0000, Color.FromRgb(255, 255, 255)}, // snow
      };

    private readonly Dictionary<double, byte[]> colorMap;
    private readonly IRandomizer randomizer;
    private readonly Stopwatch stopwatch;
    private readonly PaulBourke map;
    private readonly Timer timer;

    private double totalSeconds;
    private BitmapSource imageSource;
    private double max;
    private double min;
    private int count;
    private bool interpolate;
    private bool grayScale;
    private bool isGenerating;

    public MainWindowViewModel()
    {
      this.timer = new Timer(200);
      this.timer.Elapsed += this.OnTimer;

      this.GenerateCommand = new RelayCommand(x => this.GenerateAsync());
      this.SaveCommand = new RelayCommand(x => this.Save());
      this.randomizer = new Randomizer();
      this.stopwatch = new Stopwatch();

      this.colorMap = ColorMap.ToDictionary(x => x.Key, x => new[] { x.Value.B, x.Value.G, x.Value.R, x.Value.A });

      this.Width = 512;
      this.Height = 512;
      this.map = new PaulBourke(this.randomizer, this.Width, this.Height);
      this.Iterations = 500;
      this.GrayScale = false;
      this.Interpolate = false;
    }

    public RelayCommand GenerateCommand { get; private set; }

    public RelayCommand SaveCommand { get; private set; }

    public int Width { get; private set; }

    public int Height { get; private set; }

    public ImageSource Map
    {
      get { return this.imageSource; }
    }

    public double Iterations
    {
      get { return this.map.Iterations; }

      set { this.map.Iterations = (int)value; }
    }

    public double Scale
    {
      get { return this.map.Scale; }

      set { this.map.Scale = value; }
    }

    public bool Interpolate
    {
      get { return interpolate; }

      set
      {
        interpolate = value;
        this.OnGenerated();
      }
    }

    public double Fuzziness
    {
      get { return this.map.Fuzziness; }

      set
      {
        this.map.Fuzziness = value;
      }
    }

    public bool GrayScale
    {
      get { return grayScale; }

      set
      {
        grayScale = value;
        this.OnGenerated();
      }
    }

    public string TimeToGenerate
    {
      get { return string.Format("Time to generate map: {0:0.00}s", this.TotalSeconds); }
    }

    private double TotalSeconds
    {
      get { return this.totalSeconds; }

      set
      {
        this.totalSeconds = value;
        this.OnPropertyChanged("TimeToGenerate");
      }
    }

    public bool UseCircle
    {
      get { return this.map.DividerFlags.HasFlag(MapDivider.Circle); }

      set
      {
        if (value)
        {
          this.map.DividerFlags |= MapDivider.Circle;
        }
        else
        {
          this.map.DividerFlags &= ~MapDivider.Circle;
        }
      }
    }

    public bool UseRectangle
    {
      get { return this.map.DividerFlags.HasFlag(MapDivider.Rectangle); }

      set
      {
        if (value)
        {
          this.map.DividerFlags |= MapDivider.Rectangle;
        }
        else
        {
          this.map.DividerFlags &= ~MapDivider.Rectangle;
        }
      }
    }

    public bool UseTriangle
    {
      get { return this.map.DividerFlags.HasFlag(MapDivider.Triangle); }

      set
      {
        if (value)
        {
          this.map.DividerFlags |= MapDivider.Triangle;
        }
        else
        {
          this.map.DividerFlags &= ~MapDivider.Triangle;
        }
      }
    }

    public bool UseNormal
    {
      get { return this.map.DividerFlags.HasFlag(MapDivider.Normal); }

      set
      {
        if (value)
        {
          this.map.DividerFlags |= MapDivider.Normal;
        }
        else
        {
          this.map.DividerFlags &= ~MapDivider.Normal;
        }
      }
    }

    public bool UsePerlinNoise
    {
      get { return this.map.DividerFlags.HasFlag(MapDivider.PerlinNoise); }

      set
      {
        if (value)
        {
          this.map.DividerFlags |= MapDivider.PerlinNoise;
        }
        else
        {
          this.map.DividerFlags &= ~MapDivider.PerlinNoise;
        }
      }
    }

    public bool UseEdges
    {
      get { return this.map.UseEdge; }

      set { this.map.UseEdge = value; }
    }

    public bool CanGenerate
    {
      get { return !this.isGenerating; }
    }

    public bool CanSave
    {
      get { return this.CanGenerate && this.imageSource != null && this.imageSource.IsFrozen; }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
      PropertyChangedEventHandler handler = PropertyChanged;
      if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
    }

    private void GenerateAsync()
    {
      Task.Factory.StartNew(this.Generate);
    }

    private void Generate()
    {
      this.isGenerating = true;
      
      this.OnPropertyChanged("CanGenerate");
      this.OnPropertyChanged("CanSave");

      this.stopwatch.Restart();
      this.timer.Start();
      this.map.Generate();
      this.stopwatch.Stop();
      this.TotalSeconds = stopwatch.Elapsed.TotalSeconds;
      this.timer.Stop();
      this.OnGenerated();
      this.isGenerating = false;

      this.OnPropertyChanged("CanGenerate");
      this.OnPropertyChanged("CanSave");
    }

    private void OnTimer(object state, ElapsedEventArgs elapsedEventArgs)
    {
      this.TotalSeconds = stopwatch.Elapsed.TotalSeconds;
    }

    private void Save()
    {
      string filePath = string.Format("image_{0}.png", this.count++);
      using (var fileStream = new FileStream(filePath, FileMode.Create))
      {
        BitmapEncoder encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(this.imageSource));
        encoder.Save(fileStream);
      }
    }

    private void OnGenerated()
    {
      if (this.map.Dividers.Any())
      {
        double[] map1D = this.map.Map1D.ToArray();

        this.max = map1D.Max();
        this.min = map1D.Min();

        if (this.max == this.min)
        {
          throw new ArgumentException("min and max must be different");
        }

        byte[] bytes;

        if (!this.GrayScale)
        {
          bytes = map1D
            .SelectMany(
              x => this.GetColor(x, true))
            .ToArray();
        }
        else
        {
          bytes = map1D
            .SelectMany(this.GetGrayScale)
            .ToArray();
        }

        Bitmap bitmap = new Bitmap(this.Width, this.Height, PixelFormat.Format32bppArgb);
        BitmapData bmData = bitmap.LockBits(
          new Rectangle(0, 0, bitmap.Width, bitmap.Height),
          ImageLockMode.WriteOnly,
          bitmap.PixelFormat);
        IntPtr pNative = bmData.Scan0;

        Marshal.Copy(bytes, 0, pNative, bytes.Length);
        bitmap.UnlockBits(bmData);

        this.imageSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
          bitmap.GetHbitmap(),
          IntPtr.Zero,
          Int32Rect.Empty,
          BitmapSizeOptions.FromWidthAndHeight(bitmap.Width, bitmap.Height));

        this.imageSource.Freeze();

        this.OnPropertyChanged("Map");
      }
    }

    private IEnumerable<byte> GetColor(double value, bool normalize)
    {
      double height = normalize ? (value - this.min) / (this.max - this.min) : value;

      if (this.Interpolate)
      {
        var key1 = colorMap.TakeWhile(x => x.Key <= height).Last();
        var key2 = colorMap.SkipWhile(x => x.Key < height).First();

        double width = key2.Key - key1.Key;
        double alpha = (height - key1.Key) / width;

        return key1.Value.Zip(key2.Value, (k1, k2) => (byte)(k1 * alpha + k2 * (1d - alpha))).ToArray();
      }

      return this.colorMap.TakeWhile(x => x.Key <= height).Last().Value;
    }

    private byte[] GetGrayScale(double value)
    {
      byte gray = (byte)(255 * (value - this.min) / (this.max - this.min));

      Color color = Color.FromRgb(gray, gray, gray);

      return new[] { color.B, color.G, color.R, color.A };
    }
  }
}
