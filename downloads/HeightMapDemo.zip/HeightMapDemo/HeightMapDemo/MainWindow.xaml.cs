﻿using System.Windows;

namespace HeightMapDemo
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      this.InitializeComponent();
    }
  }
}
