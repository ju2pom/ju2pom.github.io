﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace HeightMapDemo
{
  using Dividers;

  public class PaulBourke
  {
    private readonly IRandomizer randomizer;
    private readonly int width;
    private readonly int height;
    private readonly double[,] map;
    private readonly PerlinNoise3 perlinNoise;

    private IDivider[] dividers;

    public PaulBourke(IRandomizer randomizer, int width, int height)
    {
      this.randomizer = randomizer;
      this.width = width;
      this.height = height;
      this.map = new double[height, width];
      this.Fuzziness = 15;
      this.DividerFlags = MapDivider.Normal;
      this.perlinNoise = new PerlinNoise3(randomizer) { Scale = 0.2};
    }

    public MapDivider DividerFlags { get; set; }

    public IEnumerable<IDivider> Dividers
    {
      get { return this.dividers != null ? this.dividers.ToArray() : Enumerable.Empty<IDivider>(); }
    }

    public double Scale
    {
      get { return this.perlinNoise.Scale; }

      set { this.perlinNoise.Scale = value; }
    }

    public double Fuzziness { get; set; }

    public bool UseEdge { get; set; }

    public int Iterations { get; set; }

    public IEnumerable<double> Map1D
    {
      get { return this.map.Cast<double>(); }
    }

    public void Generate()
    {
      this.Prepare();
      if (this.Fuzziness > 0)
      {
        this.perlinNoise.Prepare();
      }

      if (this.dividers != null)
      {
        Parallel.ForEach(
        (from x in Enumerable.Range(0, this.width)
         from y in Enumerable.Range(0, this.height)
         select new Point(x, y)),
        p => this.map[(int) p.Y, (int) p.X] = this.dividers.Sum(s => s.GetValue(p)));
      }
    }

    private void Prepare()
    {
      MapDivider[] allowedDividers = Enum
        .GetValues(typeof (MapDivider))
        .OfType<MapDivider>()
        .Where(x => this.DividerFlags.HasFlag(x))
        .ToArray();

      if (allowedDividers.Any())
      {
        this.dividers = Enumerable
          .Range(0, this.Iterations)
          .Select(x => this.GenerateDivider(allowedDividers))
          .ToArray();
        /*this.dividers = new IDivider[this.Iterations];
        Parallel.ForEach(Enumerable.Range(0, this.Iterations),
                           i => this.dividers[i] = this.GenerateDivider(allowedDividers));*/
      }
    }

    private IDivider GenerateDivider(MapDivider[] allowedDividers)
    {
      IDivider divider;
      Rect rect = new Rect(0, 0, this.width, this.height);
      MapDivider type = allowedDividers[this.randomizer.Next(allowedDividers.Length)];
      switch (type)
      {
        case MapDivider.Circle:
          divider = CircleDivider.Create(this.randomizer, rect);
          break;
        case MapDivider.Triangle:
          divider = TriangleDivider.Create(this.randomizer, this.width, this.height);
          break;
        case MapDivider.Rectangle:
          divider = RectangleDivider.Create(this.randomizer, this.width, this.height);
          break;
        case MapDivider.Normal:
          divider = NormalDivider.Create(this.randomizer, this.width, this.height);
          break;
        case MapDivider.PerlinNoise:
          divider = PerlinNoiseDivider.Create();
          break;
        default:
          throw new ArgumentOutOfRangeException();
      }

      divider.UseEdge = this.UseEdge;
      divider.Fuzziness = this.Fuzziness;
      divider.PerlinNoise = this.perlinNoise;

      return divider;
    }
  }
}
