﻿using System;

namespace HeightMapDemo.Extensions
{
  public static class DoubleExtensions
  {
    private const double Epsilon = 1e-6;

    public static double Clamp(this double value, double min, double max)
    {
      return Math.Min(Math.Max(value, min), max);
    }

    public static bool IsEqual(this double value, double other, double epsilon = Epsilon)
    {
      return Math.Abs(value - other) < epsilon;
    }

    public static bool IsZero(this double value, double epsilon = Epsilon)
    {
      return Math.Abs(value) < epsilon;
    }
  }
}
