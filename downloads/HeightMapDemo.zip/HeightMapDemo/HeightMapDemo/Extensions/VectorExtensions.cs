﻿using System.Windows;

namespace HeightMapDemo.Extensions
{
  public static class VectorExtensions
  {
    public static double Dot(this Vector va, Vector vb)
    {
      return va.X * vb.X + va.Y * vb.Y;
    }
  }
}
