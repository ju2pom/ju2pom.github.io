﻿using System.Linq;

namespace HeightMapDemo.Extensions
{
  using System;
  using System.Windows;

  public static class RectExtensions
  {
    public static bool IntersectCircle(this Rect rectangle, Point center, double radius)
    {
      if ((rectangle.TopLeft - center).Length < radius)
      {
        return true;
      }

      if ((rectangle.TopRight - center).Length < radius)
      {
        return true;
      }

      if ((rectangle.BottomLeft - center).Length < radius)
      {
        return true;
      }

      if ((rectangle.BottomRight - center).Length < radius)
      {
        return true;
      }

      return false;
    }

    public static double Distance(this Rect rectangle, Point p)
    {
      if (rectangle.Contains(p))
      {
        return InsideDistance(rectangle, p);
      }

      return OutsideDistance(rectangle, p);
    }

    private static double InsideDistance(Rect rectangle, Point p)
    {
      return -CalculateDistance(rectangle, p);
    }

    private static double OutsideDistance(Rect rectangle, Point p)
    {
      return CalculateDistance(rectangle, p);
    }

    private static double CalculateDistance(Rect rectangle, Point p)
    {
      double y = p.Y.Clamp(rectangle.Top, rectangle.Bottom);
      double x = p.X.Clamp(rectangle.Left, rectangle.Right);

      Point[] projection = {
        // Left
        new Point(rectangle.Left, y),
        // Right
        new Point(rectangle.Right, y),
        // Top
        new Point(x, rectangle.Top),
        // Bottom
        new Point(x, rectangle.Bottom),
        };

      return Math.Sqrt(projection.Min(o => (p - o).LengthSquared));
    }
  }
}
