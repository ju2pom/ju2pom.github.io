﻿using System;
using System.Linq;
using System.Windows;

namespace HeightMapDemo
{
  public class Randomizer : IRandomizer
  {
    private Random random;
    private int seed;

    public Randomizer(int seed = 0)
    {
      this.random = new Random(seed);
    }

    public int Seed
    {
      get
      {
        return this.seed;
      }

      set
      {
        this.seed = value;
        this.random = new Random(this.seed);
      }
    }

    public int Next(int maxValue)
    {
      return this.random.Next(maxValue);
    }

    public int Next(int minValue, int maxValue)
    {
      return this.random.Next(minValue, maxValue);
    }

    public int NextExcept(int maxValue, int except)
    {
      int value = this.random.Next(maxValue);

      while (value == except)
      {
        value = this.random.Next(maxValue);
      }

      return value;
    }

    public byte[] NextBytes(int size)
    {
      byte[] buffer = new byte[size];
      this.random.NextBytes(buffer);

      return buffer;
    }

    public byte NextByte(byte except)
    {
      byte[] buffer = new byte[3];
      this.random.NextBytes(buffer);

      return buffer.First(x => x != except);
    }

    public double NextDouble()
    {
      return this.random.NextDouble();
    }

    public Vector PickNormal()
    {
      Vector v = new Vector(2 * this.NextDouble() - 1d, 2 * this.NextDouble() - 1d);
      v.Normalize();

      return v;
    }

    public Point PickPoint(int width, int height)
    {
      return new Point(this.Next(1, width), this.Next(1, height));
    }
  }
}
