﻿namespace HeightMapDemo
{
  using System;

  [Flags]
  public enum MapDivider
  {
    Rectangle = 1,
    Triangle = 1 << 1,
    Circle = 1 << 2,
    Normal = 1 << 3,
    PerlinNoise = 1 << 4,
  }
}