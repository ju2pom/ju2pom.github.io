﻿using HeightMapDemo.Extensions;

namespace HeightMapDemo.Dividers
{
  using System.Windows;

  public class TriangleDivider : DividerBase
  {
    private readonly Point a;
    private readonly double vIn;
    private readonly double vOut;
    private readonly double dot01;
    private readonly double dot00;
    private readonly double dot11;
    private readonly double invDenom;
    private readonly Vector v1;
    private readonly Vector v0;

    public static IDivider Create(IRandomizer randomizer, int width, int height)
    {
      Point pointA = randomizer.PickPoint(width, height);
      Point pointB = randomizer.PickPoint(width, height);
      Point pointC = randomizer.PickPoint(width, height);

      Vector ab = pointA - pointB;

      while (ab.Dot(pointA - pointC).IsZero())
      {
        pointC = randomizer.PickPoint(width, height);
      }

      double valueA = 2 * randomizer.NextDouble() - 1;
      double valueB = -valueA;

      return new TriangleDivider(pointA, pointB, pointC, valueA, valueB);
    }

    private TriangleDivider(Point a, Point b, Point c, double vIn, double vOut)
    {
      this.a = a;
      this.v0 = c - a;
      this.v1 = b - a;

      this.dot00 = this.v0.Dot(this.v0);
      this.dot01 = this.v0.Dot(this.v1);
      this.dot11 = this.v1.Dot(this.v1);

      this.invDenom = 1.0 / (this.dot00 * this.dot11 - this.dot01 * this.dot01);

      this.vIn = vIn;
      this.vOut = vOut;
    }

    public override double GetValue(Point p)
    {
      Vector v2 = p - this.a;

      double dot02 = this.v0.Dot(v2);
      double dot12 = this.v1.Dot(v2);

      double u = (this.dot11 * dot02 - this.dot01 * dot12) * this.invDenom;
      double v = (this.dot00 * dot12 - this.dot01 * dot02) * this.invDenom;

      return (u >= 0.0) && (v >= 0.0) && (u + v < 1.0) ? this.vIn : this.vOut;
    }
  }
}