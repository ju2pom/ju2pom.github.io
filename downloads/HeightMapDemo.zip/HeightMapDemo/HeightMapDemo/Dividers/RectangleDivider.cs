﻿namespace HeightMapDemo.Dividers
{
  using System.Windows;

  using Extensions;

  public class RectangleDivider : DividerBase
  {
    private readonly double vIn;
    private readonly double vOut;

    private Rect rectangle;

    public static IDivider Create(IRandomizer randomizer, int width, int height)
    {
      Point pointA = new Point(randomizer.Next(width), randomizer.Next(height));

      return new RectangleDivider(pointA, randomizer.Next(width), randomizer.NextDouble(), randomizer.NextDouble());
    }

    private RectangleDivider(Point topLeft, double side, double vIn, double vOut)
    {
      this.rectangle = new Rect(topLeft, new Size(side, side));
      this.vIn = vIn;
      this.vOut = vOut;
    }

    public override double GetValue(Point p)
    {
      double distance = this.rectangle.Distance(p);

      if (distance <= 0)
      {
        return this.vIn;
      }

      //return distance;
      if (this.Fuzziness > 0 && distance < this.Fuzziness)
      {
        double generate = this.Fuzziness * this.PerlinNoise.Generate(p.X, p.Y);

        return generate > distance ? this.vIn : this.vOut;
      }

      return  this.vOut;
    }
  }
}