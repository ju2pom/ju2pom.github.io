using HeightMapDemo.Extensions;

namespace HeightMapDemo.Dividers
{
  using System;
  using System.Windows;

  public class CircleDivider : DividerBase
  {
    private readonly Point center;
    private readonly double radius;
    private readonly double vIn;
    private readonly double vOut;

    public static IDivider Create(IRandomizer randomizer, Rect rect)
    {
      int width = (int)rect.Width;
      int height = (int) rect.Height;

      Point pointA = new Point(randomizer.Next(width), randomizer.Next(height));
      double radius = randomizer.Next(width);

      while (!rect.IntersectCircle(pointA, radius))
      {
        pointA = new Point(randomizer.Next(width), randomizer.Next(height));
        radius = randomizer.Next(width);
      }

      double valueA = 2 * randomizer.NextDouble() - 1;
      double valueB = -valueA;

      return new CircleDivider(pointA, radius, valueA, valueB);
    }

    private CircleDivider(Point center, double radius, double vIn, double vOut)
    {
      this.center = center;
      this.radius = radius;
      this.vIn = vIn;
      this.vOut = vOut;
    }

    public override double GetValue(Point p)
    {
      double distance = (p - this.center).Length - this.radius;

      if (this.Fuzziness > 0 && Math.Abs(distance) < this.Fuzziness)
      {
        double generate = this.Fuzziness * this.PerlinNoise.Generate(p.X, p.Y);

        return generate < distance ? this.vIn : this.vOut;
      }

      if (this.UseEdge)
      {
        return Math.Abs(distance) < 0.5 ? this.vIn : this.vOut;
      }

      return distance > 0 ? this.vIn : this.vOut;
    }
  }
}
