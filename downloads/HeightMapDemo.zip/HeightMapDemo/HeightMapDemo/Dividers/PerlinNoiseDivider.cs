﻿namespace HeightMapDemo.Dividers
{
  using System.Windows;

  public class PerlinNoiseDivider : DividerBase
  {
    public static IDivider Create()
    {
      return new PerlinNoiseDivider();
    }

    public override double GetValue(Point p)
    {
      return this.PerlinNoise.Generate(p.X, p.Y);
    }
  }
}
