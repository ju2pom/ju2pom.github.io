﻿namespace HeightMapDemo.Dividers
{
  using System;
  using System.Windows;

  public class NormalDivider : DividerBase
  {
    private readonly Point origin;
    private readonly Vector normal;
    private readonly double va;
    private readonly double vb;

    public static IDivider Create(IRandomizer randomizer, int width, int height)
    {
      Point pointA = randomizer.PickPoint(width, height);
      Vector normal = randomizer.PickNormal();

      double valueA = randomizer.NextDouble();
      double valueB = -valueA;

      return new NormalDivider(pointA, normal, valueA, valueB);
    }

    private NormalDivider(Point a, Vector n, double va, double vb)
    {
      this.origin = a;
      this.normal = n;
      this.va = va;
      this.vb = vb;
    }

    public override double GetValue(Point p)
    {
      Vector v = this.origin - p;

      if (this.UseEdge)
      {
        return Math.Abs(v.X * this.normal.X + v.Y * this.normal.Y) < 0.5 ? 10d : 0d;
      }
      
      double distance = v.X * this.normal.X + v.Y * this.normal.Y;

      if (this.Fuzziness > 0 && Math.Abs(distance) < this.Fuzziness)
      {
        double generate = this.Fuzziness*this.PerlinNoise.Generate(p.X, p.Y);

        return generate > distance ? this.va : this.vb;
      }

      return distance < 0 ? this.va : this.vb;
    }
  }
}
