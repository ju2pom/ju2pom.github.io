﻿namespace HeightMapDemo.Dividers
{
  using System.Windows;

  public abstract class DividerBase : IDivider
  {
    public bool UseEdge { get; set; }

    public double Fuzziness { get; set; }

    public PerlinNoise3 PerlinNoise { get; set; }

    public abstract double GetValue(Point p);
  }
}
