﻿using System.Windows;

namespace HeightMapDemo
{
  public interface IRandomizer
  {
    int Seed { get; set; }

    int Next(int maxValue);

    int Next(int minValue, int maxValue);

    int NextExcept(int maxValue, int except);

    byte[] NextBytes(int size);

    byte NextByte(byte except);

    double NextDouble();

    Vector PickNormal();

    Point PickPoint(int width, int height);
  }
}