﻿namespace HeightMapDemo
{
  using System.Windows;

  public interface IDivider
  {
    bool UseEdge { get; set; }

    double Fuzziness { get; set; }

    PerlinNoise3 PerlinNoise { get; set; }

    double GetValue(Point p);
  }
}